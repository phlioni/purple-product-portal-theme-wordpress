<?php
/**
 * Purple Product Portal Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Purple_Product_Portal_Theme
 */

if ( ! defined( '_S_VERSION' ) ) {
	// Replace the version number of the theme on each release.
	define( '_S_VERSION', '1.0.0' );
}

/**
 * Enqueue scripts and styles.
 */
function purple_product_portal_scripts() {
	// Enqueue Theme Stylesheet
	wp_enqueue_style( 'purple-product-portal-style', get_stylesheet_uri(), array(), _S_VERSION );

	// Enqueue Tailwind/Main CSS from build
	wp_enqueue_style( 'purple-product-portal-main-css', get_template_directory_uri() . '/assets/css/index-S7Nfg8Yh.css', array(), _S_VERSION );

	// Enqueue JS from build
	// The browser script seems small, might be a polyfill or helper
	wp_enqueue_script( 'purple-product-portal-browser-js', get_template_directory_uri() . '/assets/js/browser-CrIXV1sM.js', array(), _S_VERSION, true );
	// The main index JS - contains the React app logic. This won't run correctly without the React environment and root element setup, but we enqueue it as requested.
	wp_enqueue_script( 'purple-product-portal-index-js', get_template_directory_uri() . '/assets/js/index-CRJ_quch.js', array(), _S_VERSION, true );

	// Add Google Fonts
	wp_enqueue_style( 'google-fonts-inter-tight', 'https://fonts.googleapis.com/css2?family=Inter+Tight:wght@300;400;500;600;700&display=swap', array(), null );

}
add_action( 'wp_enqueue_scripts', 'purple_product_portal_scripts' );

/**
 * Add theme support features.
 */
function purple_product_portal_setup() {
	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'menu-1' => esc_html__( 'Primary', 'purple-product-portal' ),
		)
	);

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );

}
add_action( 'after_setup_theme', 'purple_product_portal_setup' );

// Basic setup complete. More features like custom post types or taxonomies would go here if needed.



/**
 * Register Custom Post Type: Produto
 */
function purple_product_portal_register_produto_cpt() {

	$labels = array(
		'name'                  => _x( 'Produtos', 'Post Type General Name', 'purple-product-portal' ),
		'singular_name'         => _x( 'Produto', 'Post Type Singular Name', 'purple-product-portal' ),
		'menu_name'             => __( 'Produtos', 'purple-product-portal' ),
		'name_admin_bar'        => __( 'Produto', 'purple-product-portal' ),
		'archives'              => __( 'Arquivos de Produtos', 'purple-product-portal' ),
		'attributes'            => __( 'Atributos do Produto', 'purple-product-portal' ),
		'parent_item_colon'     => __( 'Produto Pai:', 'purple-product-portal' ),
		'all_items'             => __( 'Todos os Produtos', 'purple-product-portal' ),
		'add_new_item'          => __( 'Adicionar Novo Produto', 'purple-product-portal' ),
		'add_new'               => __( 'Adicionar Novo', 'purple-product-portal' ),
		'new_item'              => __( 'Novo Produto', 'purple-product-portal' ),
		'edit_item'             => __( 'Editar Produto', 'purple-product-portal' ),
		'update_item'           => __( 'Atualizar Produto', 'purple-product-portal' ),
		'view_item'             => __( 'Ver Produto', 'purple-product-portal' ),
		'view_items'            => __( 'Ver Produtos', 'purple-product-portal' ),
		'search_items'          => __( 'Buscar Produto', 'purple-product-portal' ),
		'not_found'             => __( 'Nenhum produto encontrado', 'purple-product-portal' ),
		'not_found_in_trash'    => __( 'Nenhum produto encontrado na lixeira', 'purple-product-portal' ),
		'featured_image'        => __( 'Imagem do Produto', 'purple-product-portal' ),
		'set_featured_image'    => __( 'Definir imagem do produto', 'purple-product-portal' ),
		'remove_featured_image' => __( 'Remover imagem do produto', 'purple-product-portal' ),
		'use_featured_image'    => __( 'Usar como imagem do produto', 'purple-product-portal' ),
		'insert_into_item'      => __( 'Inserir no produto', 'purple-product-portal' ),
		'uploaded_to_this_item' => __( 'Enviado para este produto', 'purple-product-portal' ),
		'items_list'            => __( 'Lista de produtos', 'purple-product-portal' ),
		'items_list_navigation' => __( 'Navegação da lista de produtos', 'purple-product-portal' ),
		'filter_items_list'     => __( 'Filtrar lista de produtos', 'purple-product-portal' ),
	);
	$args = array(
		'label'                 => __( 'Produto', 'purple-product-portal' ),
		'description'           => __( 'Post Type para Produtos', 'purple-product-portal' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'custom-fields', 'author' ), // Added 'author'
		'taxonomies'            => array( 'categoria_produto' ), // Will register this taxonomy later
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-cart',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'produto',
        'capabilities' => array(
            'edit_post'          => 'edit_produto',
            'read_post'          => 'read_produto',
            'delete_post'        => 'delete_produto',
            'edit_posts'         => 'edit_produtos',
            'edit_others_posts'  => 'edit_others_produtos',
            'publish_posts'      => 'publish_produtos',
            'read_private_posts' => 'read_private_produtos',
            'create_posts'       => 'edit_produtos', // Allows contributors to create posts but not publish
        ),
        'map_meta_cap'        => true, // Needed for author-specific editing and capability mapping
		'rewrite'               => array('slug' => 'produtos'), // URL slug
	);
	register_post_type( 'produto', $args );

}
add_action( 'init', 'purple_product_portal_register_produto_cpt', 0 );

/**
 * Register Custom Taxonomy: Categoria de Produto
 */
function purple_product_portal_register_categoria_taxonomy() {

	$labels = array(
		'name'                       => _x( 'Categorias de Produto', 'Taxonomy General Name', 'purple-product-portal' ),
		'singular_name'              => _x( 'Categoria de Produto', 'Taxonomy Singular Name', 'purple-product-portal' ),
		'menu_name'                  => __( 'Categorias', 'purple-product-portal' ),
		'all_items'                  => __( 'Todas as Categorias', 'purple-product-portal' ),
		'parent_item'                => __( 'Categoria Pai', 'purple-product-portal' ),
		'parent_item_colon'          => __( 'Categoria Pai:', 'purple-product-portal' ),
		'new_item_name'              => __( 'Nova Categoria', 'purple-product-portal' ),
		'add_new_item'               => __( 'Adicionar Nova Categoria', 'purple-product-portal' ),
		'edit_item'                  => __( 'Editar Categoria', 'purple-product-portal' ),
		'update_item'                => __( 'Atualizar Categoria', 'purple-product-portal' ),
		'view_item'                  => __( 'Ver Categoria', 'purple-product-portal' ),
		'separate_items_with_commas' => __( 'Separar categorias com vírgulas', 'purple-product-portal' ),
		'add_or_remove_items'        => __( 'Adicionar ou remover categorias', 'purple-product-portal' ),
		'choose_from_most_used'      => __( 'Escolher das categorias mais usadas', 'purple-product-portal' ),
		'popular_items'              => __( 'Categorias Populares', 'purple-product-portal' ),
		'search_items'               => __( 'Buscar Categorias', 'purple-product-portal' ),
		'not_found'                  => __( 'Nenhuma categoria encontrada', 'purple-product-portal' ),
		'no_terms'                   => __( 'Nenhuma categoria', 'purple-product-portal' ),
		'items_list'                 => __( 'Lista de categorias', 'purple-product-portal' ),
		'items_list_navigation'      => __( 'Navegação da lista de categorias', 'purple-product-portal' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true, // Like post categories
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
        'rewrite'                    => array( 'slug' => 'categoria-produto' ), // URL slug
	);
	register_taxonomy( 'categoria_produto', array( 'produto' ), $args ); // Associate with 'produto' CPT

}
add_action( 'init', 'purple_product_portal_register_categoria_taxonomy', 0 );

/**
 * Add Custom Meta Boxes for Product Links and Data Inicio
 */
function purple_product_portal_add_meta_boxes() {
    add_meta_box(
        'produto_links_metabox',
        __( 'Links do Produto', 'purple-product-portal' ),
        'purple_product_portal_links_metabox_html',
        'produto', // CPT slug
        'normal', // context
        'high' // priority
    );
    add_meta_box(
        'produto_data_inicio_metabox',
        __( 'Data de Início', 'purple-product-portal' ),
        'purple_product_portal_data_inicio_metabox_html',
        'produto',
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'purple_product_portal_add_meta_boxes' );

/**
 * HTML for Links Meta Box
 */
function purple_product_portal_links_metabox_html( $post ) {
    wp_nonce_field( 'produto_links_nonce_action', 'produto_links_nonce' );

    $links = get_post_meta( $post->ID, '_produto_links', true );
    $link_fields = [
        'loop' => 'OnePage (Loop)',
        'figma' => 'Figma',
        'especificacao' => 'Especificação',
        'landpage' => 'Landing Page',
        'manual' => 'Manual Técnico',
        'faq' => 'FAQ para Clientes'
    ];

    echo '<table class="form-table"><tbody>';
    foreach ($link_fields as $key => $label) {
        $value = isset($links[$key]) ? esc_url($links[$key]) : '';
        echo '<tr>';
        echo '<th scope="row"><label for="produto_link_' . esc_attr($key) . '">' . esc_html($label) . '</label></th>';
        echo '<td><input type="url" id="produto_link_' . esc_attr($key) . '" name="produto_links[' . esc_attr($key) . ']" value="' . $value . '" class="regular-text"></td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
}

/**
 * HTML for Data Inicio Meta Box
 */
function purple_product_portal_data_inicio_metabox_html( $post ) {
    wp_nonce_field( 'produto_data_inicio_nonce_action', 'produto_data_inicio_nonce' );
    $value = get_post_meta( $post->ID, '_produto_data_inicio', true );
    echo '<label for="produto_data_inicio">' . __( 'Data:', 'purple-product-portal' ) . '</label> ';
    echo '<input type="date" id="produto_data_inicio" name="produto_data_inicio" value="' . esc_attr( $value ) . '" />';
}

/**
 * Save Meta Box Data
 */
function purple_product_portal_save_metadata( $post_id ) {
    // Save Links
    if ( isset( $_POST['produto_links_nonce'] ) && wp_verify_nonce( $_POST['produto_links_nonce'], 'produto_links_nonce_action' ) ) {
        if ( isset( $_POST['produto_links'] ) && is_array( $_POST['produto_links'] ) ) {
            $sanitized_links = array_map( 'esc_url_raw', $_POST['produto_links'] );
            update_post_meta( $post_id, '_produto_links', $sanitized_links );
        } else {
            delete_post_meta( $post_id, '_produto_links' );
        }
    }

    // Save Data Inicio
    if ( isset( $_POST['produto_data_inicio_nonce'] ) && wp_verify_nonce( $_POST['produto_data_inicio_nonce'], 'produto_data_inicio_nonce_action' ) ) {
        if ( isset( $_POST['produto_data_inicio'] ) ) {
            $sanitized_date = sanitize_text_field( $_POST['produto_data_inicio'] );
            // Basic validation for YYYY-MM-DD format
            if ( preg_match("/^\d{4}-\d{2}-\d{2}$/", $sanitized_date) ) {
                 update_post_meta( $post_id, '_produto_data_inicio', $sanitized_date );
            } else {
                 delete_post_meta( $post_id, '_produto_data_inicio' ); // Delete if invalid format
            }
        } else {
            delete_post_meta( $post_id, '_produto_data_inicio' );
        }
    }
}
add_action( 'save_post_produto', 'purple_product_portal_save_metadata' ); // Hook into save_post_{cpt_slug}




/**
 * Assign custom capabilities to roles on theme activation
 */
function purple_product_portal_add_caps_to_roles() {
    $admin_role = get_role( 'administrator' );
    if ( $admin_role ) {
        $admin_role->add_cap( 'edit_produto' );
        $admin_role->add_cap( 'read_produto' );
        $admin_role->add_cap( 'delete_produto' );
        $admin_role->add_cap( 'edit_produtos' );
        $admin_role->add_cap( 'edit_others_produtos' );
        $admin_role->add_cap( 'publish_produtos' );
        $admin_role->add_cap( 'read_private_produtos' );
        $admin_role->add_cap( 'delete_produtos' ); // Add capability to delete multiple posts
        $admin_role->add_cap( 'delete_published_produtos' );
        $admin_role->add_cap( 'delete_others_produtos' );
        $admin_role->add_cap( 'edit_published_produtos' );
        $admin_role->add_cap( 'delete_private_produtos' );
        $admin_role->add_cap( 'edit_private_produtos' );
    }

    // Example: Give Editor role similar capabilities (adjust as needed)
    $editor_role = get_role( 'editor' );
    if ( $editor_role ) {
        $editor_role->add_cap( 'edit_produto' );
        $editor_role->add_cap( 'read_produto' );
        $editor_role->add_cap( 'delete_produto' );
        $editor_role->add_cap( 'edit_produtos' );
        $editor_role->add_cap( 'edit_others_produtos' );
        $editor_role->add_cap( 'publish_produtos' );
        $editor_role->add_cap( 'read_private_produtos' );
        $editor_role->add_cap( 'delete_produtos' );
        $editor_role->add_cap( 'delete_published_produtos' );
        $editor_role->add_cap( 'delete_others_produtos' );
        $editor_role->add_cap( 'edit_published_produtos' );
        $editor_role->add_cap( 'delete_private_produtos' );
        $editor_role->add_cap( 'edit_private_produtos' );
    }

    // Example: Give Author role capabilities for their own products
    $author_role = get_role( 'author' );
    if ( $author_role ) {
        $author_role->add_cap( 'edit_produto' );
        $author_role->add_cap( 'read_produto' );
        $author_role->add_cap( 'delete_produto' );
        $author_role->add_cap( 'edit_produtos' );
        $author_role->add_cap( 'publish_produtos' );
        $author_role->add_cap( 'delete_published_produtos' );
        // Authors typically cannot edit/delete others' posts
    }

    // Example: Give Contributor role capability to create/edit but not publish
    $contributor_role = get_role( 'contributor' );
    if ( $contributor_role ) {
        $contributor_role->add_cap( 'edit_produto' );
        $contributor_role->add_cap( 'read_produto' );
        $contributor_role->add_cap( 'delete_produto' ); // Allow deleting drafts
        $contributor_role->add_cap( 'edit_produtos' );
    }
}
// Run once on theme activation
add_action( 'after_switch_theme', 'purple_product_portal_add_caps_to_roles' );

// Optional: Remove caps on theme deactivation (good practice)
function purple_product_portal_remove_caps_from_roles() {
    $roles_to_modify = [ 'administrator', 'editor', 'author', 'contributor' ];
    $caps_to_remove = [
        'edit_produto', 'read_produto', 'delete_produto',
        'edit_produtos', 'edit_others_produtos', 'publish_produtos',
        'read_private_produtos', 'delete_produtos', 'delete_published_produtos',
        'delete_others_produtos', 'edit_published_produtos', 'delete_private_produtos',
        'edit_private_produtos'
    ];

    foreach ( $roles_to_modify as $role_name ) {
        $role = get_role( $role_name );
        if ( $role ) {
            foreach ( $caps_to_remove as $cap ) {
                $role->remove_cap( $cap );
            }
        }
    }
}
add_action( 'switch_theme', 'purple_product_portal_remove_caps_from_roles' );


