<?php
/**
 * The template for displaying single Produto posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Purple_Product_Portal_Theme
 */

get_header();
?>

	<main id="primary" class="site-main container mx-auto px-6 py-8">

		<?php
		while ( have_posts() ) : the_post();

            $produto_id = get_the_ID();
            $produto_links = get_post_meta( $produto_id, 
                                            '_produto_links
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                                            ', true );
            $produto_data_inicio = get_post_meta( $produto_id, 
                                                  '_produto_data_inicio
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                                                  ', true );
            $produto_categorias = get_the_terms( $produto_id, 'categoria_produto' );

            ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class("bg-branco rounded-lg shadow-md border border-gelo-20 p-6 md:p-8"); ?>>
				<header class="entry-header mb-6 border-b border-gelo-10 pb-6">
                    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <?php the_title( 
                            '<h1 class="entry-title text-3xl font-bold text-roxo-principal">', 
                            '</h1>' 
                        ); ?>
                        <?php if ( current_user_can( 'edit_post', $produto_id ) ) : ?>
                            <div class="flex-shrink-0">
                                <?php
                                edit_post_link(
                                    esc_html__( 'Editar Produto
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                                    ', 'purple-product-portal' ),
                                    '<span class="edit-link btn-secondary text-sm">', // Add classes here
                                    '</span>'
                                );
                                ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="entry-meta text-sm text-gelo-20 mt-3">
                        <span>Publicado em <?php echo get_the_date(); ?></span>
                        <?php if ( $produto_data_inicio ) : ?>
                            <span class="mx-2">|</span>
                            <span>Início do Projeto: <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $produto_data_inicio ) ) ); ?></span>
                        <?php endif; ?>
                        <?php if ( $produto_categorias && ! is_wp_error( $produto_categorias ) ) : ?>
                            <span class="mx-2">|</span>
                            <span>Categorias: 
                                <?php
                                    $category_links = array();
                                    foreach ( $produto_categorias as $category ) {
                                        $category_links[] = sprintf( 
                                            '<a href="%1$s" class="hover:text-roxo-principal">%2$s</a>',
                                            esc_url( get_term_link( $category->term_id, 'categoria_produto' ) ),
                                            esc_html( $category->name )
                                        );
                                    }
                                    echo implode( ", ", $category_links );
                                ?>
                            </span>
                        <?php endif; ?>
                    </div><!-- .entry-meta -->
				</header><!-- .entry-header -->

                <div class="entry-content space-y-6">

                    <?php if ( has_post_thumbnail() ) : ?>
                        <div class="post-thumbnail mb-6">
                            <?php the_post_thumbnail( 'large', array('class' => 'w-full h-auto rounded-lg shadow-sm border border-gelo-10') ); ?>
                        </div><!-- .post-thumbnail -->
                    <?php endif; ?>

					<?php
                        // Display post content if available (from editor)
                        if ( get_the_content() ) {
                            the_content();
                        }
                    ?>

                    <?php 
                    // Display Product Links
                    if ( ! empty( $produto_links ) && is_array( $produto_links ) ) : 
                        $link_labels = [
                            'loop' => '🔗 OnePage (Loop)
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            ',
                            'figma' => '🎨 Figma
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            ',
                            'especificacao' => '📄 Especificação
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            ',
                            'landpage' => '🌐 Landing Page
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            ',
                            'manual' => '🔗 Manual Técnico
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            ',
                            'faq' => '🔗 FAQ para Clientes
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                            '
                        ];
                        $has_links = false;
                        foreach ($link_labels as $key => $label) {
                            if (!empty($produto_links[$key])) {
                                $has_links = true;
                                break;
                            }
                        }

                        if ($has_links) : ?>
                            <div class="produto-links mt-6 pt-6 border-t border-gelo-10">
                                <h3 class="text-xl font-semibold text-preto mb-4">Links do Projeto</h3>
                                <ul class="list-none space-y-2">
                                    <?php foreach ($link_labels as $key => $label) : ?>
                                        <?php if ( ! empty( $produto_links[$key] ) ) : ?>
                                            <li>
                                                <span class="font-medium"><?php echo esc_html($label); ?>:</span> 
                                                <a href="<?php echo esc_url( $produto_links[$key] ); ?>" target="_blank" rel="noopener noreferrer" class="text-roxo-principal hover:underline break-all">
                                                    <?php echo esc_html( $produto_links[$key] ); ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

				</div><!-- .entry-content -->

				<footer class="entry-footer mt-8 pt-6 border-t border-gelo-10">
                    <?php 
                        // Previous/next post navigation.
                        the_post_navigation(
                            array(
                                'prev_text' => '<span class="nav-subtitle" aria-hidden="true">' . esc_html__( 'Anterior:
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                                ', 'purple-product-portal' ) . '</span> <span class="nav-title">%title</span>',
                                'next_text' => '<span class="nav-subtitle" aria-hidden="true">' . esc_html__( 'Próximo:
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.
                                ', 'purple-product-portal' ) . '</span> <span class="nav-title">%title</span>',
                            )
                        );
                    ?>
				</footer><!-- .entry-footer -->
			</article><!-- #post-<?php the_ID(); ?> -->

			<?php
			// If comments are open or we have at least one comment, load up the comment template.
			// if ( comments_open() || get_comments_number() ) :
			// 	comments_template();
			// endif;

		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();

