<?php
/**
 * The template for displaying archive pages for the 'produto' CPT
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Purple_Product_Portal_Theme
 */

get_header();
?>

	<main id="primary" class="site-main container mx-auto px-6 py-8">

		<?php if ( have_posts() ) : ?>

			<header class="page-header mb-6">
				<?php
					the_archive_title( 
                        '<h1 class="page-title text-3xl font-bold text-roxo-principal mb-2">', 
                        '</h1>' 
                    );
					the_archive_description( 
                        '<div class="archive-description text-gelo-20">', 
                        '</div>' 
                    );
				?>
			</header><!-- .page-header -->

            <?php
            // TODO: Add Search and Filter form here later
            ?>

            <div class="mb-6">
              <p class="text-gelo-20 font-medium">
                <?php 
                    global $wp_query;
                    $count = $wp_query->found_posts;
                    printf( 
                        _n( 
                            '%s produto encontrado
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.', 
                            '%s produtos encontrados
Please note: This is a basic implementation. The dynamic functionality of the React app (including Supabase integration) needs to be rebuilt using WordPress functions or potentially by using WordPress as a headless CMS.', 
                            $count, 
                            'purple-product-portal' 
                        ),
                        number_format_i18n( $count )
                    );
                ?>
              </p>
            </div>

			<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
				<?php
				/* Start the Loop */
				while ( have_posts() ) : the_post();

					/*
					 * Include the Post-Type-specific template for the content.
					 * Or create a template part: get_template_part( 'template-parts/content', 'produto' );
					 */
                     ?>
                     <article id="post-<?php the_ID(); ?>" <?php post_class('bg-branco rounded-lg shadow-md border border-gelo-20 overflow-hidden flex flex-col'); ?>>
                        <header class="entry-header">
                            <?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php the_permalink(); ?>" class="block aspect-video overflow-hidden">
                                    <?php the_post_thumbnail('medium_large', array('class' => 'w-full h-full object-cover group-hover:scale-105 transition-transform duration-300')); ?>
                                </a>
                            <?php else : ?>
                                <a href="<?php the_permalink(); ?>" class="block aspect-video bg-gelo flex items-center justify-center">
                                    <span class="text-gelo-20 text-sm">Sem Imagem</span>
                                </a>
                            <?php endif; ?>
                        </header><!-- .entry-header -->

                        <div class="entry-content p-4 flex-grow flex flex-col">
                            <?php the_title( sprintf( '<h2 class="entry-title text-lg font-semibold text-preto mb-2 flex-grow"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
                            
                            <div class="entry-meta text-sm text-gelo-20 mt-auto pt-2">
                                <?php
                                    $categories = get_the_terms( get_the_ID(), 'categoria_produto' );
                                    if ( $categories && ! is_wp_error( $categories ) ) :
                                        $category_links = array();
                                        foreach ( $categories as $category ) {
                                            $category_links[] = sprintf( 
                                                '<a href="%1$s" class="hover:text-roxo-principal">%2$s</a>',
                                                esc_url( get_term_link( $category->term_id, 'categoria_produto' ) ),
                                                esc_html( $category->name )
                                            );
                                        }
                                        echo implode( ', ', $category_links );
                                    endif;
                                ?>
                            </div><!-- .entry-meta -->
                        </div><!-- .entry-content -->

                        <?php if ( current_user_can( 'edit_post', get_the_ID() ) ) : ?>
                            <footer class="entry-footer p-4 border-t border-gelo-10 bg-gelo-50">
                                <?php
                                edit_post_link(
                                    sprintf(
                                        /* translators: %s: Name of current post. Only visible to screen readers */
                                        esc_html__( 'Editar %s', 'purple-product-portal' ),
                                        '<span class="screen-reader-text">' . get_the_title() . '</span>'
                                    ),
                                    '<span class="edit-link text-roxo-principal hover:underline text-sm">', // Add classes here
                                    '</span>'
                                );
                                ?>
                            </footer><!-- .entry-footer -->
                        <?php endif; ?>
                    </article><!-- #post-<?php the_ID(); ?> -->
                    <?php
				endwhile;
                ?>
            </div>
            <?php
			the_posts_navigation(); // Simple Previous/Next page links

		else : // If no content
            ?>
            <section class="no-results not-found text-center py-16">
                <header class="page-header mb-4">
                    <h1 class="page-title text-2xl font-bold text-preto"><?php esc_html_e( 'Nenhum produto encontrado', 'purple-product-portal' ); ?></h1>
                </header><!-- .page-header -->

                <div class="page-content">
                    <?php if ( is_search() ) : ?>
                        <p><?php esc_html_e( 'Desculpe, mas nada corresponde aos seus termos de pesquisa. Por favor, tente novamente com algumas palavras-chave diferentes.', 'purple-product-portal' ); ?></p>
                        <?php // get_search_form(); ?>
                    <?php else : ?>
                        <p><?php esc_html_e( 'Parece que não conseguimos encontrar o que você está procurando. Talvez tentar uma busca?', 'purple-product-portal' ); ?></p>
                        <?php // get_search_form(); ?>
                    <?php endif; ?>
                    <?php if ( current_user_can( 'publish_posts' ) ) : ?>
                        <p class="mt-4"><a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=produto' ) ); ?>" class="btn-primary"><?php esc_html_e( 'Adicionar Novo Produto', 'purple-product-portal' ); ?></a></p>
                    <?php endif; ?>
                </div><!-- .page-content -->
            </section><!-- .no-results -->
            <?php
		endif;
		?>

	</main><!-- #main -->

<?php
get_footer();

